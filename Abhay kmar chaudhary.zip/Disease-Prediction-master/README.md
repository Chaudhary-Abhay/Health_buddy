# Disease-Prediction
A multi disease prediction web app based machine learning
To view visit https://ml-based-disease-prediction.herokuapp.com/
